
https://discord.gg/GrheGZnt9s
https://discord.gg/GrheGZnt9s
https://discord.gg/GrheGZnt9s

Mettez ca dans ox_intenry/data/item.lua 

	['bmx'] = {
        label = 'BMX',
        weight = 2,
        stack = false,
        close = true,
        description = 'Un BMX pliable',
        client = {
        event = 'bmx:use'
    }
},

https://discord.gg/GrheGZnt9s
https://discord.gg/GrheGZnt9s
https://discord.gg/GrheGZnt9s