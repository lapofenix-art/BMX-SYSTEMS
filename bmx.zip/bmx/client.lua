--https://discord.gg/GrheGZnt9s
-- Utilisation de l'item BMX
print("KZB")

RegisterNetEvent('bmx:use', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    RequestAnimDict('anim@heists@money_grab@briefcase')
    while not HasAnimDictLoaded('anim@heists@money_grab@briefcase') do
        Wait(0)
    end

    TaskPlayAnim(ped, 'anim@heists@money_grab@briefcase', 'put_down_case', 8.0, -8.0, 1500, 49, 0, false, false, false)
    Wait(1500)
    ClearPedTasks(ped)

    local model = joaat('bmx')
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end

    local forward = GetEntityForwardVector(ped)
    local spawnCoords = coords + (forward * 1.5)

    local vehicle = CreateVehicle(model, spawnCoords.x, spawnCoords.y, spawnCoords.z, heading, true, false)
    SetVehicleOnGroundProperly(vehicle)
    SetEntityAsMissionEntity(vehicle, true, true)
    SetModelAsNoLongerNeeded(model)

    TriggerServerEvent('bmx:removeItem')
end)

--https://discord.gg/GrheGZnt9s
-- 👇 TARGET POUR RAMASSER LE BMX (À METTRE ICI)
CreateThread(function()
    exports.ox_target:addModel(joaat('bmx'), {
        {
            label = 'Ramasser le BMX',
            icon = 'bicycle',
            distance = 2.0,
            onSelect = function(data)
                local vehicle = data.entity

                TaskStartScenarioInPlace(PlayerPedId(), 'WORLD_HUMAN_PICKUP', 0, true)
                Wait(1200)
                ClearPedTasks(PlayerPedId())

                TriggerServerEvent('bmx:pickup', VehToNet(vehicle))
            end
        }
    })
end)
--https://discord.gg/GrheGZnt9s