--Fait par KZB 
--https://discord.gg/GrheGZnt9s
--https://discord.gg/GrheGZnt9s
--https://discord.gg/GrheGZnt9s

--Merci de pas le Revendre !

fx_version 'cerulean'
game 'gta5'

description 'BMX Item - ox_inventory'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'ox_inventory',
    'ox_target'
}
