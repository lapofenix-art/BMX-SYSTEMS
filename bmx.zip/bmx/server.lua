--https://discord.gg/GrheGZnt9s
print("KZB")

RegisterNetEvent('bmx:removeItem', function()
    local src = source
    exports.ox_inventory:RemoveItem(src, 'bmx', 1)
end)

RegisterNetEvent('bmx:pickup', function(netId)
    local src = source
    local entity = NetworkGetEntityFromNetworkId(netId)

    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
        exports.ox_inventory:AddItem(src, 'bmx', 1)
    end
end)
--https://discord.gg/GrheGZnt9s